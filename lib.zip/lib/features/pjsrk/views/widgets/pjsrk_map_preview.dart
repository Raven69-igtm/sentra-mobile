import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';

class PjsrkMapPreview extends StatefulWidget {
  /// Dipanggil setiap kali user pilih lokasi (tap peta atau GPS)
  final Function(double lat, double lng)? onLocationChanged;

  /// Controller form alamat di bawah peta (biar otomatis terisi)
  final TextEditingController? addressController;

  const PjsrkMapPreview({
    super.key,
    this.onLocationChanged,
    this.addressController,
  });

  @override
  State<PjsrkMapPreview> createState() => _PjsrkMapPreviewState();
}

class _PjsrkMapPreviewState extends State<PjsrkMapPreview> {
  GoogleMapController? _mapController;

  // Default: sekitar Nganjuk / Kediri
  LatLng _current = const LatLng(-7.6056, 111.9010);
  bool _loadingGps = false;

  Set<Marker> get _markers => {
        Marker(
          markerId: const MarkerId('selected'),
          position: _current,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
        ),
      };

  Future<void> _getMyLocation() async {
    setState(() => _loadingGps = true);

    try {
      // Cek GPS nyala atau tidak
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _snack('GPS belum dinyalakan');
        return;
      }

      // Minta izin lokasi
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          _snack('Izin lokasi ditolak');
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        _snack('Izin lokasi ditolak permanen. Buka pengaturan HP.');
        return;
      }

      // Ambil posisi sekarang
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );

      final newPos = LatLng(pos.latitude, pos.longitude);

      setState(() {
        _current = newPos;
      });

      // Pindahkan kamera ke lokasi user
      await _mapController?.animateCamera(
        CameraUpdate.newLatLngZoom(newPos, 16),
      );

      // Kirim koordinat ke parent (controller)
      widget.onLocationChanged?.call(pos.latitude, pos.longitude);

      // Isi form alamat di bawah (sementara pakai koordinat)
      // Nanti bisa diganti reverse geocoding (Mapbox / Google)
      if (widget.addressController != null) {
        widget.addressController!.text =
            'Lat ${pos.latitude.toStringAsFixed(5)}, Lng ${pos.longitude.toStringAsFixed(5)}';
      }
    } catch (e) {
      _snack('Gagal ambil lokasi: $e');
    } finally {
      if (mounted) setState(() => _loadingGps = false);
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontFamily: 'Mulish')),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: SizedBox(
        height: 180,
        child: Stack(
          children: [
            // ===== PETA GOOGLE =====
            GoogleMap(
              initialCameraPosition: CameraPosition(
                target: _current,
                zoom: 15,
              ),
              markers: _markers,
              myLocationEnabled: false, // kita pakai tombol sendiri
              myLocationButtonEnabled: false,
              zoomControlsEnabled: false,
              mapToolbarEnabled: false,
              onMapCreated: (controller) {
                _mapController = controller;
              },
              onTap: (LatLng pos) {
                // User ketuk peta → pindah pin
                setState(() => _current = pos);
                widget.onLocationChanged?.call(pos.latitude, pos.longitude);

                if (widget.addressController != null) {
                  widget.addressController!.text =
                      'Lat ${pos.latitude.toStringAsFixed(5)}, Lng ${pos.longitude.toStringAsFixed(5)}';
                }
              },
            ),

            // ===== TOMBOL "LOKASI SAYA" =====
            Positioned(
              right: 12,
              bottom: 12,
              child: GestureDetector(
                onTap: _loadingGps ? null : _getMyLocation,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.15),
                        blurRadius: 6,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (_loadingGps)
                        const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      else
                        const Icon(
                          Icons.my_location,
                          size: 18,
                          color: Color(0xFF2E7D32),
                        ),
                      const SizedBox(width: 6),
                      const Text(
                        'Lokasi saya',
                        style: TextStyle(
                          fontFamily: 'Mulish',
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF2E7D32),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}